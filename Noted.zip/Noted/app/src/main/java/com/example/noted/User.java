package com.example.noted;

public class User {
    public String email, password;

    public User() {}
    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }
}